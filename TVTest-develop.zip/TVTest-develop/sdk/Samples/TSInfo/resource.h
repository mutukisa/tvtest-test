#define IDD_MAIN 10

#define IDC_SPACE               100
#define IDC_CHANNEL             101
#define IDC_NETWORKID           102
#define IDC_NETWORKNAME         103
#define IDC_TRANSPORTSTREAMID   104
#define IDC_TRANSPORTSTREAMNAME 105
#define IDC_REMOTECONTROLKEYID  106
#define IDC_SERVICE             107
#define IDC_SERVICEID           108
#define IDC_SERVICENAME         109
#define IDC_VIDEOPID            110
#define IDC_AUDIOPID            111
#define IDC_SUBTITLEPID         112
