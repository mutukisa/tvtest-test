#define IDB_ICON    1
#define IDM_MENU    10

#define CM_VIEW_LIST            100
#define CM_VIEW_LOGO            101
#define CM_LOGOSIZE_SMALL       102
#define CM_LOGOSIZE_MEDIUM      103
#define CM_LOGOSIZE_LARGE       104
#define CM_LOGOSIZE_EXTRALARGE  105
