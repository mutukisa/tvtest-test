#define IDB_SHOW  1
#define IDB_ONOFF 2
